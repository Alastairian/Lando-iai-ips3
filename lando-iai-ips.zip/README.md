# Lando - IAI-IPS

A Next.js + TypeScript + Tailwind chatbot scaffold for your dual-core IAI-IPS cognition system and IQCL interpreter.

- Live IQCL chat
- Logs Logos/Pathos simulation
- Ready for Vercel deployment